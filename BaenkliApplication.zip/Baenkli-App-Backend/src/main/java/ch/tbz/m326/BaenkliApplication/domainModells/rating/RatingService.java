package ch.tbz.m326.BaenkliApplication.domainModells.rating;

import ch.tbz.m326.BaenkliApplication.config.generic.ExtendedService;

public interface RatingService extends ExtendedService<Rating> {
}

