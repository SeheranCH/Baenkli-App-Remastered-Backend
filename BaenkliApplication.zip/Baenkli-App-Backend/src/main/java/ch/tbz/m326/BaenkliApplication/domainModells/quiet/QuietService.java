package ch.tbz.m326.BaenkliApplication.domainModells.quiet;

import ch.tbz.m326.BaenkliApplication.config.generic.ExtendedService;

public interface QuietService extends ExtendedService<Quiet> {
}
