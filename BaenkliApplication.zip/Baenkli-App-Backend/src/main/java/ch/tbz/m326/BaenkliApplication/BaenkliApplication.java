package ch.tbz.m326.BaenkliApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaenkliApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaenkliApplication.class, args);
	}

}
