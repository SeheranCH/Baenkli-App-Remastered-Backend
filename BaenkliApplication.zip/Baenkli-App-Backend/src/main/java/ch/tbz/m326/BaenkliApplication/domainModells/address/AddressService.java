package ch.tbz.m326.BaenkliApplication.domainModells.address;

import ch.tbz.m326.BaenkliApplication.config.generic.ExtendedService;

public interface AddressService extends ExtendedService<Address> {
}
